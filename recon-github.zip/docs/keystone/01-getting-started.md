# 01 · Getting Started with Keystone

**Keystone · by Tigapo — Internal Documentation**

---

## What you'll have after this guide

- Platform open and rendering in your browser
- Venue data loaded and visible on the Dashboard
- Your name set in the activity panel so pipeline moves are attributed to you
- Understanding of how data flows through the system

**Time required: ~10 minutes**

---

## 1. Open the Platform

Keystone is a single self-contained HTML file. No install. No server. No login. No external dependencies at runtime.

1. Locate `FEC-Intelligence-Platform.html` in the shared **FEC PROJECT** folder on SharePoint (synced to your OneDrive desktop)
2. Open it in **Google Chrome** or **Microsoft Edge**
   - Firefox and Safari work but may be slightly slower on large datasets
3. The platform loads entirely in your browser — all logic, scoring, and enrichment runs client-side

> **Offline-capable.** Once the file is open and data is loaded, you can work without internet access. Map tiles require internet; all data, scoring, and filtering does not.

---

## 2. First Load — Demo / Seed Data

On first open with no CSVs loaded, the platform displays **demo seed data** so the UI is never empty. You will see:
- A pre-populated venue list with realistic-looking FEC records
- A working map with pins
- Sample scores and statuses across the pipeline

This seed data is illustrative only — replace it with real data by following the steps below.

---

## 3. Loading Real Data

There are two paths to get fresh data into the platform.

### Path A: SharePoint / Microsoft Graph API (recommended when configured)

This path requires an Azure AD app `clientId` to be stored in the platform settings (done once by your admin):

1. Click **Sync data** in the top-right of any page
2. If a client ID is configured AND you're on an `http://` or `https://` origin, the platform calls the **Microsoft Graph API silently** using MSAL (Microsoft Authentication Library)
3. It fetches the latest CSVs directly from the shared SharePoint drive:
   - `FEC PROJECT/fec_venues (1).csv` — the prospect universe
   - `FEC PROJECT/all_venues_master.csv` — Tigapo master install base
4. No file picking required — data arrives automatically

**If Graph API is not configured or fails silently** (e.g. you're working from a local file path `file://`), the platform **automatically falls back to the local file picker** — no error, no prompt, just the file picker appears.

### Path B: Local File Picker (works everywhere, no setup)

1. Click **Sync data** → **Pick files**
2. Select one or more of your locally-synced copies from the OneDrive **FEC PROJECT** folder
3. The platform **auto-detects file type by reading the header row** — you can select multiple files at once:
   - `fec_venues (1).csv` — detected as prospect universe (has `name`, `city`, `country`, etc.)
   - `all_venues_master.csv` — detected as Tigapo master list (has `tigapo` column or is loaded with `asTigapo` flag)
   - Arcade market dataset — detected as country-level market data (has `locations`, `revenue`, `continent` etc. — no per-venue rows)
4. Each file type goes into the correct store automatically

### Path C: CSV Import (Data Sources page)

For Apollo exports, custom discovery batches, or one-off lists:

1. Navigate to **Sources** in the sidebar
2. Use the **Venue universe — import CSV** card
3. Paste CSV text directly OR click **Choose file**
4. A preview shows: row count, fresh vs. duplicate count, columns detected, and which columns were auto-mapped
5. Click **Import** — rows are deduplicated on a synthetic `placeId` key before merging

---

## 4. How CSV Merging Works

When you load both the prospect CSV (`fec_venues`) and the Tigapo master CSV (`all_venues_master`), the platform **merges them automatically**:

1. Each venue is keyed on `(name + country).toLowerCase()`
2. Prospects that match a Tigapo master row are **flagged as customers**: `tigapo: true`, `posSystem: 'Tigapo'`, `status: 'customer'`
3. Tigapo master venues not in the prospect list are **appended** as customer-status records
4. The result: a single combined dataset showing both prospects and existing customers, with no duplicates

---

## 5. CSV Format Reference

### Prospect / Venue Universe CSV

The importer recognises these headers automatically (case-insensitive, partial match):

| Category | Recognised header patterns |
|----------|-----------------------------|
| Name | `name`, `title`, `company` |
| Location | `city`, `town`, `country`, `state`, `region`, `province`, `address`, `neighborhood` |
| Contact | `website`, `url`, `domain`, `phone`, `telephone` |
| Coordinates | `lat`, `lng`, `lon` |
| Quality signals | `rating`, `stars`, `totalscore`, `reviews`, `review_count` |
| Classification | `category`, `industry` |

### Country / Market Dataset CSV

Expected columns for the Market Intelligence panel:

| Column | Description |
|--------|------------|
| `country` | Country name |
| `flag` | Emoji flag (optional) |
| `continent` | Continent grouping |
| `locations` | Estimated FEC venue count |
| `machines` | Estimated amusement machines |
| `revenue` | Annual market revenue (USD) |
| `tigapo_venues` | Tigapo installs |
| `payment_systems` | Comma-separated incumbent POS/payment systems |
| `major_chains` | Comma-separated known chains |

---

## 6. Interface Orientation

```
┌────────────────────────────────────────────────────────────────┐
│  SIDEBAR (left, 248px)                                         │
│  ┌──────────┐   Dashboard / Map / Pipeline /                   │
│  │ KEYSTONE │   Locations / Compare / Sources                  │
│  │ Tigapo   │                                                  │
│  └──────────┘   ← collapse arrow on sidebar edge              │
│                                                                │
│  Bottom of sidebar:  🌙/☀ Dark/Light toggle · ⚙ Settings     │
├────────────────────────────────────────────────────────────────┤
│  TOPBAR (64px)                                                 │
│  Page title · breadcrumb           [Sync data] [Ask AI ✦]    │
├────────────────────────────────────────────────────────────────┤
│  MAIN CONTENT                                                  │
│  Scrollable per page                                           │
└────────────────────────────────────────────────────────────────┘
```

**Dark/Light mode toggle:** At the **bottom of the sidebar**, next to the Settings icon. Click to switch between the dark (default) and light themes.

**Sidebar collapse:** Click the **◁** arrow on the right edge of the sidebar to collapse it to icon-only mode (68px wide). Click again to expand. Useful on small laptop screens and during demos.

**Mobile:** On narrow screens (< 760px), the sidebar is **hidden by default** and positioned off-screen. Tap the **hamburger menu icon** (top-left of the topbar) to slide the sidebar in. Tap outside the sidebar or tap the same icon to close it.

---

## 7. Setting Your Name — Team Activity Attribution

Keystone maintains a shared team activity feed — every pipeline status change is timestamped and attributed to the person who made it.

**To set your name:**

1. Open **Settings** (bottom of the sidebar)
2. Enter your name in the **Your name** field
3. It saves automatically to browser storage

From that point forward, every time you move a lead through a pipeline stage, the activity feed records:  
`Sarah Chen advanced Galaxy FEC → Qualified · 2 min ago`

> **Do this before you start working.** If you leave the field blank, actions are attributed to "Teammate" — not useful for team accountability.

---

## 8. Geocoding — Getting Precise Map Pins

Venues imported with only an address (no lat/lng) appear at their country centroid until geocoded. To get precise pins:

1. Go to **Sources** → scroll to **Geocode addresses → precise pins**
2. Choose a provider:
   - **Nominatim (free)** — ~1 request/second per OSM policy. Results cached — never re-fetches the same address
   - **Mapbox (fast)** — ~8 requests/second, requires a free Mapbox access token (`pk.…`)
3. Set a **max per run** and click **Geocode**
4. Progress bar shows completion. Pin positions update on the map immediately

---

## 9. Quick-Start Checklist

Get productive in 15 minutes:

- [ ] Open the HTML file in Chrome or Edge
- [ ] Click **Sync data** → select CSVs from the FEC PROJECT folder
- [ ] Set your name in Settings → activity attribution
- [ ] Open **Dashboard** — scan the KPI strip and market depth panel
- [ ] Open **Map** → switch to **Score mode** → zoom into your territory
- [ ] Find a green (score 80+) cluster and click a venue
- [ ] Click "View in Locations" from the pop-up → read the outreach message
- [ ] Export to CRM or copy the email draft

---

## Next Steps

- **[02 — Dashboard](02-dashboard.md)** — understand every KPI card and panel
- **[03 — Map](03-map.md)** — master the 5 map modes
- **[04 — Pipeline](04-pipeline.md)** — manage lead stages and enrichment

---

*Keystone · by Tigapo · Confidential*
