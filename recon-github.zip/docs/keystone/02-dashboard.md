# 02 · Dashboard

**Keystone · by Tigapo — Internal Documentation**

---

## Overview

The Dashboard is the command centre. It answers *"Where do we stand right now?"* at every level — individual pipeline health, global market position, competitive landscape, and penetration by continent and segment.

---

## The KPI Strip (Top Row)

Seven headline numbers always visible at the top. Each KPI card also shows a **sparkline trend** showing how the metric has moved over recent enrichment cycles:

| KPI | What it measures | How to use it |
|-----|-----------------|---------------|
| **Total venues** | Count of all venues in the database | Cross-check against your last import |
| **With email** | Verified email address present | Primary outbound reach metric |
| **With phone** | Verified phone number present | Direct outreach readiness |
| **Owner LinkedIn** | Decision-maker LinkedIn profile found | Identifies qualification depth |
| **Avg lead score** | Mean score across all scored venues | Territory quality benchmark |
| **Qualified** | In active pipeline (`qualified` + `exported` status) | Working pipeline depth |
| **Exported** | Pushed to CRM / outbound tool | Active outreach count |

> **Sparklines matter.** A rising email count sparkline means your enrichment pipeline is running well. A flat qualified sparkline means reps are not reviewing scored leads fast enough.

---

## Pipeline Funnel Card

Shows the flow from discovery to export as a count at each stage:

```
   Raw  →  Enriched  →  Scored  →  Qualified  →  Exported
          (contact       (AI-        (sales        (CRM /
           data)         ranked)      ready)        sent)
                                                  Disqualified
```

Use this to identify where leads are getting stuck. Large Raw + small Enriched → run enrichment. Large Scored + small Qualified → reps need to review. Large Qualified + small Exported → outreach bottleneck.

---

## Market Depth Panel

The global market size view. Sourced from IAAPA research, national industry bodies, and Tigapo's own install base — not from the venue database.

| KPI | Description |
|-----|------------|
| **Global market revenue** | Annual blended revenue across the FEC industry (USD) |
| **Revenue CAGR** | Compound annual growth rate with sparkline — the 2–3× growth story made visual |
| **FEC locations** | Total estimated FEC venues globally |
| **Machines deployed** | Total amusement machines in service globally |

**Top markets by revenue:** Bar chart of leading FEC markets ranked by revenue, with Tigapo penetration % per country and country-level CAGR. Green bars = Tigapo present; amber = open market.

**Machine-type mix:** Chart showing the global split by machine category (redemption, video, kiddie, cranes, etc.) — useful for segment targeting conversations.

**Coverage matrix:** A segment × region heatmap. Rows are venue types:
- Trampoline parks
- Arcades
- Laser tag
- Mini golf
- Go-karts
- Bowling
- FEC multi-attraction
- Indoor playgrounds
- Escape rooms
- Axe throwing

Columns are regions. Cells are colour-coded by venue density — darker = more venues discovered. Use this to spot which segment × region combinations are under-mapped and worth a targeted discovery run.

---

## Market Concentration Card

The fragmentation picture — explains why a displacement play is viable.

| Metric | Description |
|--------|------------|
| **HHI score** | Herfindahl-Hirschman Index — measures market concentration. Low HHI = fragmented (many small players). High HHI = concentrated (one dominant player). FEC's low HHI explains why no single POS system dominates. |
| **Top-3 system share** | Combined market share of the three most common POS systems across the venue dataset |
| **Market leader** | The single most common POS system and its approximate share |

> **What "fragmented" means for Tigapo:** No incumbent has locked up the market. A fragmented, growing market is the ideal entry condition — many venues with many different (or no) systems, all reachable with the right story.

---

## Market Benchmarks Card

Industry averages across all venues in the dataset — useful for calibrating what "good" looks like in a market before prospecting a new region:

| Benchmark | Description |
|-----------|------------|
| **Avg rating** | Mean Google star rating across all enriched venues |
| **Median review count** | Median review count — a proxy for venue size and throughput |
| **% with website** | How many venues have a confirmed web presence |
| **% with email** | Outreach readiness across the dataset |
| **% with POS** | POS penetration — how many venues have any detectable POS |
| **% with booking** | Booking system penetration |
| **% high-rated** | Venues rated ≥ 4.3★ — the ICP quality threshold |

Use benchmarks before targeting a new geography: if the benchmark email % for Australia is 45% and you're seeing 20% in your prospect list, your enrichment run for that territory is incomplete.

---

## Rival Profiles Panel

A collapsible reference section showing **Tigapo vs every system found in the field**. For each competitor encountered in the venue dataset:

| Field | Description |
|-------|------------|
| Company name | Competitor name |
| Type | Legacy / FEC Specialist / Horizontal POS |
| Origin | Country of company origin |
| Description | What they do and who they serve |
| Key feature tags | Their main selling points (e.g. "cloud-native," "RFID tokens," "online booking") |
| Venue count | How many venues in your dataset run this system |

Use the Rival Profiles panel to quickly brief yourself before a competitive call, or to help a new rep understand the landscape before they prospect into a region dominated by one system.

---

## Market Context Panel (Three Tabs)

A tabbed panel providing deeper context on market dynamics. Requires the arcade market dataset to be loaded.

### Tab 1: Payment Landscape

**Cashless maturity by region:** Shows the balance of cashless / hybrid / cash-based payment environments across regions. Regions high in cash-dominant venues are greenfield conversion opportunities — they're not using any payment system yet.

**Top payment systems:** Which cashless and payment systems (Tigapo rivals and partners) are most common in each region, with approximate market reach.

**Tigapo's fit:** Where Tigapo's cashless + Nayax hardware model fits naturally (established cashless markets for competitive displacement) vs. where it's educational (cash-dominant markets where the conversion story leads).

### Tab 2: Market Notes

Country-by-country intelligence notes sorted by market revenue. Each row contains:
- Country and flag
- Market revenue
- Key intelligence note (e.g. "Strong growth in entertainment retail; ROLLER dominant in trampoline; significant whitespace in independent arcades")
- Tigapo penetration status

Use this tab before a territory deep-dive to read existing context without re-doing the research.

### Tab 3: Associations

Industry body links by region, including:
- IAAPA (global — International Association of Amusement Parks and Attractions)
- National FEC/amusement associations by country
- LinkedIn group links (where available)

Use for: event research, conference attendance decisions, association member list acquisition, partnership conversations.

---

## Sources & Methodology Panel

An expandable list of **primary research sources** with:
- Source name (e.g. "IAAPA 2024 Global Attractions Outlook")
- Source type (industry report / national research / government / Tigapo internal)
- Key figures cited from that source
- Country-level research reference count (how many country notes rely on this source)

This panel exists for credibility in leadership and investor briefings — the market numbers have citable sources, not just estimates.

---

## Reading the Dashboard as a Story

A well-loaded Keystone dataset tells a story in four beats:

1. **How big is the market?** → Market Depth panel headline KPIs + CAGR sparkline
2. **How much do we own?** → KPI strip Exported count + Market Depth Tigapo penetration %
3. **Where is the gap?** → Market Concentration (HHI) + Rival Profiles venue counts
4. **What should I work today?** → Pipeline funnel (where is the bottleneck?) + KPI with email count

If you can answer all four in under 60 seconds, the data is healthy and you're ready to work the map.

---

## Common Dashboard Questions

**"Why is penetration so low?"**
Global FEC penetration is intentionally low by design — Keystone is mapping the long tail of independents nobody else tracks. Even 2–3% global penetration with a 3× growth market is a very large opportunity.

**"The Market Depth panel shows no data"**
Import the arcade market dataset. Go to Sources → **Country market data** → Choose file. The arcade market CSV has `locations`, `revenue`, and `continent` columns (not per-venue rows).

**"My email count seems low for the region"**
Check the benchmark: if the dataset benchmark for that region is higher than what you're seeing, your enrichment run for that territory is incomplete. Run Apollo enrichment against the filtered set.

**"What is HHI and why should I care?"**
HHI (Herfindahl-Hirschman Index) = sum of squared market shares. Below 1,500 = fragmented (good for a new entrant like Tigapo). Above 2,500 = concentrated (one dominant player; harder entry). FEC POS is fragmented — Tigapo's opening.

---

*Keystone · by Tigapo · Confidential*
