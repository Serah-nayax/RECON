# 05 · Locations & Outreach

**Keystone · by Tigapo — Internal Documentation**

---

## Overview

The Locations page is the most detail-dense view in Keystone. Every venue in the database is listed, searchable, and filterable. Click any venue to open a full intelligence panel — contact details, enrichment signals, score breakdown, competitive context, sentiment analysis, and a ready-to-send personalised outreach message.

---

## The Venue Table

Default sort is **Lead Score descending** — your best leads are always at the top.

### Columns

| Column | Description |
|--------|------------|
| **Name** | Venue name. Click to open the detail panel. |
| **City / Country** | Location |
| **Score** | Lead score pill (0–100, colour-coded) + Tier badge (A/B/C/D) |
| **Recommended action** | `call_now` / `nurture` / `monitor` / `disqualify` |
| **Status** | Current pipeline stage |
| **POS** | Detected POS system or "—" for whitespace |
| **Email** | ✓ or blank |
| **Rating** | Google star rating |
| **Tier** | T1 / T2 / T3 |

**Sorting:** Click any column header to sort. Click again for descending.

---

## Searching and Filtering

| Filter | Options |
|--------|---------|
| **Search text** | Name, city, country, POS system |
| **Country** | All countries in dataset |
| **Status** | Raw / Enriched / Scored / Qualified / Exported / Disqualified |
| **Tier** | T1 / T2 / T3 |
| **Competitive class** | Whitespace / Legacy / Specialist / Horizontal |
| **Has email** | Toggle |
| **In ICP** | Toggle |
| **Recommended action** | call_now / nurture / monitor / disqualify |
| **Tech gap** | Legacy POS / No booking / No website / Greenfield |
| **Min score** | Slider (0–100) |

---

## Venue Detail Panel

Clicking any venue opens a slide-over panel on the right with full intelligence.

### Score breakdown
- Large lead score number (colour-coded by tier A/B/C/D)
- Each signal shows ✓ or ✗ with its point value
- `scoreBrief` — one-line plain-English assessment
- `recommendedAction` — automated work queue instruction
- **Confidence score** (0.00–0.97) — trust indicator for the score

### Review sentiment
The auto-generated sentiment line translates the rating + review count into a Tigapo pitch angle:
- High-rating, high-volume: *"Guests rave about the experience... Peak-hour wait times — a throughput/booking gap Tigapo addresses."*
- Moderate-rating: *"Solid reputation... checkout/queue delays — operational pain Tigapo solves."*
- Low-rating: *"Mixed reviews citing slow service and payment issues — strong modernization case."*

### Tech gap signals
Flags surfaced for the rep — displayed as labelled chips on the detail panel:
- `Legacy POS detected (Siriusware)` — migration pitch
- `No online booking system` — upsell wedge
- `No website — likely cash-only / offline ops` — education-first
- `No detectable POS — greenfield` — land-and-expand

### Contact intelligence

| Field | Source |
|-------|--------|
| Email | Apollo / Apify enrichment |
| Phone | Google Maps / Apollo |
| Owner name | Apollo decision-maker lookup |
| Owner LinkedIn | Apollo enrichment |
| Website | Google Maps / enrichment |

Email addresses have a **copy** button. LinkedIn URLs open in a new tab.

### Competitive context

| Field | Description |
|-------|------------|
| POS system | Detected system (or "No POS — whitespace") |
| Competitive class | Whitespace / Legacy / Specialist / Horizontal |
| Booking system | Detected booking platform or "No booking detected" |
| Machine count | If available from enrichment data |
| Revenue tier | If available from enrichment |

---

## Competitive Play Types

Every venue is classified into a competitive play. This classification drives the outreach hook, the CRM export field, and the map colour in Rivals mode:

| Play type | What it means | Recommended approach |
|-----------|--------------|----------------------|
| **Whitespace** | No POS detected | Greenfield — land POS + booking, then expand modules |
| **Legacy rival** | Siriusware / Centaman / Clover | Displace — lead with migration + Nayax payments story |
| **FEC specialist** | ROLLER / Embed / Semnox / CenterEdge / Sacoa / Intercard | Differentiate on integrated payments + hardware; exploit booking gap |
| **Horizontal POS** | Lightspeed / Square / Shopify | Upgrade to FEC-native; no online booking = upsell wedge |
| **Tigapo customer** | Already installed | Expand — cross-sell modules, add machine count |

---

## Operator Segmentation (Nayax Product Fit Tiers)

| Tier | Name | Fleet size | Right product | Description |
|------|------|-----------|--------------|-------------|
| **T1** | Unattended | 1–5 machines | Nayax payment reader | Single-machine ops: kiddie rides, claw machines, vending |
| **T2** | Semi-attended | 3–15 machines | Reader + management software | Mid-size staffed venues: bars, bowling, mini golf, route operators |
| **T3** | Flagship | 15+ machines | Full Tigapo platform suite | Fully-staffed arcades & FECs with redemption counters |

Tier is **auto-assigned** from machine count if known; otherwise **inferred** from venue category keywords (e.g. a "redemption" flag overrides machine count, classifying directly as T3).

---

## Outreach Message Generator

At the bottom of every venue detail panel, Keystone auto-drafts **three outreach formats**:

1. **Email subject line** — tailored to tier and competitive situation
2. **Email body** — owner first name, venue name, city, competitive hook, product pitch, CTA
3. **LinkedIn note** — shorter version of the email body

### How the hook is chosen

| Competitive situation | Email hook |
|----------------------|-----------|
| **Whitespace** (no POS) | *"I noticed [Venue] runs largely on cash / manual ops — operators who move to cashless typically see 15–25% higher per-cap spend."* |
| **Legacy POS** | *"I saw [Venue] is on [POS]. Many operators are migrating off legacy systems to cut downtime and add mobile + cashless."* |
| **Specialist / horizontal POS** | *"[Venue] runs [POS] — worth seeing how Nayax/Tigapo compares on integrated payments + hardware."* |

### Personalisation

The message is pre-written with:
- Owner first name (from enrichment) — *"Hi Sarah,"*
- Venue name and city
- Competitive hook based on the play type
- A Tigapo/Nayax credibility line (e.g. number of FEC customers globally)

**Add before sending:**
- A local market reference
- A relevant customer reference (nearby venue, same operator type)
- A timing hook (conference, new year, quarter-end, recent news)

---

## CRM Export — Three Formats

Clicking **Export to CRM** (top-right of the Locations page) opens a format picker:

### Format 1: Salesforce-Ready CSV

Two sheets in the exported file:

**Accounts sheet** (brand-level rollup):

| Column | Description |
|--------|------------|
| `AccountName` | Brand / chain name or venue name |
| `Industry` | "Family Entertainment Center" |
| `BillingCity`, `BillingCountry` | Location |
| `NumberOfLocations` | Count of locations for this brand in dataset |
| `Markets` | Countries in which this brand operates |
| `OperatorSegment` | T1 / T2 / T3 |
| `CompetitiveStatus` | Whitespace / Legacy / Specialist / Horizontal |
| `PriorityScore` | 0–100 CRM priority ranking |
| `Tigapo_Installed__c` | Boolean custom field |

**Venues sheet** (individual location rows):

| Column | Description |
|--------|------------|
| `LeadSource` | "Keystone by Tigapo" |
| `Company` | Venue name |
| `City`, `Country` | Location |
| `Website` | Business website |
| `Email` | Verified contact email |
| `Phone` | Direct phone |
| `FirstName`, `LastName` | Owner name (split) |
| `LinkedInUrl__c` | Owner LinkedIn |
| `Lead_Score__c` | 0–100 lead score |
| `Priority_Score__c` | 0–100 priority score |
| `POS_System__c` | Detected POS |
| `Competitive_Class__c` | Whitespace / Legacy / Specialist / Horizontal |
| `Operator_Tier__c` | T1 / T2 / T3 |
| `Status` | Pipeline status |
| `Outreach_Message__c` | Pre-written email body |
| `Score_Brief__c` | One-line scoring rationale |
| `Recommended_Action__c` | call_now / nurture / monitor / disqualify |

### Format 2: HubSpot-Ready CSV

Same dual-sheet structure as Salesforce. Column names match HubSpot's default import field names:
- `Company Name`, `Contact Email`, `Contact Phone`, `First Name`, `Last Name`
- Custom properties: `hs_lead_score`, `operator_tier`, `competitive_class`, `pos_system`, `priority_score`
- Association columns link Contacts to Companies automatically on import

### Format 3: Generic CSV

A single flat sheet with all fields, no HubSpot/Salesforce-specific formatting. Use this for:
- Excel-based pipeline management
- Custom CRM imports
- Sharing with a partner or external agency

---

## Bulk Export from Locations

To export a filtered set:

1. Apply filters (e.g. Country = UK, Status = Qualified, Has email = ✓)
2. Click **Export CSV** → select format
3. Only currently-visible (filtered) rows are exported
4. The export respects active filters

---

## Working a Call List — Step by Step

**Preparation (5 minutes):**
1. Filter: Status = Scored, Has email = ✓, Recommended action = call_now
2. Sort by Lead Score descending
3. Click the top venue → read the detail panel
4. Advance to Qualified if it looks ready
5. Repeat for the next 10–20 venues

**Outreach (per venue):**
1. Open the detail panel → Copy the outreach message
2. Add a personalisation line (local reference, customer reference, timing hook)
3. Send from your email client
4. Log in your CRM
5. Change status to Exported in Keystone

**A/B note on confidence:** When two venues have the same score, prioritise the one with higher confidence. A score-85 venue with confidence 0.92 should be called before a score-87 venue with confidence 0.51.

---

## Changing Status from the Detail Panel

1. Open the venue detail panel
2. Click the **Status badge** (becomes a dropdown)
3. Select the new status
4. Change saves immediately and is recorded in the team activity feed
5. The change is reflected in the Pipeline board in real time

---

*Keystone · by Tigapo · Confidential*
