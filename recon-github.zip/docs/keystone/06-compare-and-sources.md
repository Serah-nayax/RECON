# 06 · Compare, Sources & AI Copilot

**Keystone · by Tigapo — Internal Documentation**

---

## Part A: Compare Page

### Overview

The Compare page benchmarks any two geographic markets side by side. Pick any two regions from your dataset — countries, continents, or named territories — and Keystone builds a parallel intelligence card for each, showing where one market is stronger or weaker than the other.

Use this for: territory planning, resource allocation decisions, VP/leadership briefings, and pre-conference market prep.

---

### How to Use Compare

1. Navigate to **Compare** in the left sidebar
2. Select **Region A** from the left dropdown (any geographic grouping in your data)
3. Select **Region B** from the right dropdown
4. The comparison renders instantly — no loading required, all data is already in memory

---

### What Each Region Card Shows

| Metric | Description |
|--------|------------|
| **Venue count** | Total venues discovered in this region |
| **Qualified** | Venues in `qualified` or `exported` status |
| **Avg lead score** | Mean score across all scored venues |
| **Avg rating** | Mean Google star rating |
| **% with email** | Contactable ratio — outreach readiness |
| **% with POS** | Market saturation (any POS system) |
| **% whitespace** | Venues with no POS detected |
| **Top cities** | Top 4 cities by venue count |
| **Top POS systems** | Most common competitor systems in this market |

---

### Reading the Comparison

**Higher avg score + lower % with POS** = greenfield market. Lots of quality venues, not yet saturated with competitor systems. Good entry market.

**Lower avg score + higher % with email** = high-touch market. Harder to score, but reachable. Relationship-building play, not spray-and-pray.

**High legacy % in one region vs. high whitespace % in another** = two completely different motions. The legacy region needs a migration/displacement pitch; the whitespace region needs education and first-deal simplicity.

---

### Exporting a Comparison

Click **Export PDF** or **Copy summary** to get a shareable snapshot of the two-region comparison. This is the fastest way to prep a slide for a region review meeting — paste the numbers directly or use the markdown export as a slide draft.

---

### Common Compare Use Cases

| Scenario | How to use Compare |
|----------|-------------------|
| "Should I focus on Germany or France this half?" | Compare Germany vs. France. Higher score avg + higher email % + more whitespace = better market to enter first |
| "Which of our two new AEs should cover APAC vs. EMEA?" | Compare APAC vs. EMEA. Assign the more aggressive territory to the more senior rep |
| "Board deck needs a comparison of our two biggest markets" | Compare US vs. UK (or whichever two). Export the side-by-side. Done in 3 minutes |

---

---

## Part B: Data Sources

### Overview

The Sources page is where you connect external data pipelines, import CSVs, geocode addresses, and manage API credentials. It operates in two modes:

| Mode | Description | When to use |
|------|------------|-------------|
| **Standalone** | All data is local. No external server needed. | Day-to-day use by reps |
| **Live API** | Connected to a backend server managing real pipeline runs | Power users, technical admins |

---

### Connecting Apify (Live Google Maps Discovery)

Apify runs the Google Maps scraping actor that powers Keystone's discovery layer. Connecting your Apify account unlocks live scan runs directly from the browser.

**Steps:**
1. Go to [console.apify.com/account/integrations](https://console.apify.com/account/integrations) and copy your API token
2. In Keystone → Sources, paste the token in the **Connect Apify** card
3. Click **Connect** — the platform verifies the token and displays your account username
4. A green "Connected" chip confirms success. The token is stored only in your browser — never sent to external servers

**Running a discovery scan:**

1. In Sources → **Apify · Google Maps discovery**, click **Run scan**
2. Configure:
   - **Keywords** — select from pre-set FEC terms (family entertainment center, trampoline park, arcade, bowling, etc.) or add custom terms
   - **Location mode** — by location name (e.g. "Texas") or by custom geographic grid
   - **Max per search** — how many places to return per keyword × location combination (default 40)
3. Click **Run** — Keystone calls the Apify actor synchronously (results come back in the same browser tab). Each search unit takes 1–3 minutes
4. Results are auto-parsed and merged into the venue dataset with deduplication

**Grid mode (advanced):**
Define a geographic bounding box (south lat, north lat, west lng, east lng) with a step size and search radius. The platform generates a grid of search points covering the box. Useful for high-density metro areas where a single location query returns too few results.

**Rate limits and batch sizes:**
- Keep scan batches under 25 search units per run (browser 5-minute timeout cap)
- Each unit is 1 keyword × 1 location — 3 keywords × 5 locations = 15 units per run
- For large geographies, run multiple smaller batches

---

### Source Catalogue — Discovery

| Source | Status | Description |
|--------|--------|------------|
| **Apify · Google Maps** | Ready (with token) | Primary discovery engine. Scrapes Google Maps for any keyword in any geography. Returns name, address, phone, website, hours, categories, rating, reviews, photos |
| **CSV import** | Always ready | Import any Apollo, ZoomInfo, or custom CSV. Auto-maps 30+ column patterns |
| **Apollo.io seed** | Ready (with key) | Uses Apollo's database for initial contact seeding. Email + decision-maker data |
| **Apify dataset fetch** | Ready (with token) | Pull from an existing Apify dataset by dataset ID. Use for pre-run scrapes |

**Status badges:**
- 🟢 `ready` — configured and functional
- 🔵 `demo` — available as simulated demo mode
- 🟡 `scaffold` — implemented in the backend but needs environment variables set
- ⚫ `not configured` — requires setup before use

---

### Source Catalogue — Enrichment

| Source | Description |
|--------|------------|
| **Website detection** | Rule-based detection from Google Maps data — no API required |
| **Email finder** | Apollo.io contact lookup for owner/manager email. Requires Apollo API key |
| **Phone verification** | Cross-references phone numbers against known business registries |
| **LinkedIn decision-maker** | Apollo lookup for owner name, title, and LinkedIn URL |
| **Review count & rating** | Extracted from Google Maps scrape — no extra cost |
| **POS system detection** | Keyword pattern matching on website text + tech stack signals |
| **Booking system detection** | URL pattern matching + meta-tag scanning |
| **Geocoding** | Nominatim (free) or Mapbox (fast). Converts address → lat/lng |

---

### Apollo API Key

Apollo provides decision-maker email and LinkedIn data. The key is stored only in your browser.

1. Get your key from [Apollo.io](https://app.apollo.io/#/settings/integrations/api) → API settings
2. Paste it in Sources → **Other API keys** → Apollo API key field
3. Apollo enrichment runs inside the Apify actor — the key is passed as `APOLLO_API_KEY`
4. CORS restrictions prevent direct browser-to-Apollo calls; the key must flow through the Apify actor to work

---

### Tigapo Master List Import

The Tigapo master CSV (`all_venues_master.csv`) marks existing customers so they appear as pulsing cyan pins on the map and are excluded from outbound targeting.

1. Sources → **Tigapo market position**
2. Click **Choose file** → select your `all_venues_master.csv`
3. The platform reads the `tigapo` column (or marks all rows as Tigapo if using the **asTigapo** import mode)
4. Matched venues in the prospect list are updated to `status: customer`, `posSystem: Tigapo`
5. Unmatched Tigapo venues not in the prospect list are appended as customer-status records

---

### Country Market Data Import

The country-level market data powers the Market Intelligence panel on the Dashboard.

Expected CSV columns (headers are flexible — auto-detected):

| Column | Description |
|--------|------------|
| `country` | Country name |
| `flag` | Emoji flag (optional) |
| `continent` | Continent grouping |
| `locations` | Estimated FEC venue count |
| `machines` | Estimated amusement machines |
| `revenue` | Annual market revenue (USD) |
| `tigapo_venues` | Tigapo installs in this country |
| `tigapo_machines` | Tigapo machines in this country |
| `penetration` | Pre-calculated penetration % (optional) |
| `payment_systems` | Comma-separated list of incumbent payment/POS systems |
| `major_chains` | Comma-separated list of known chains/operators |

---

### Connecting to a Live Backend (Advanced)

If a backend API server has been deployed:

1. Sources → **Connect to a live backend**
2. Enter the API base URL (e.g. `https://your-app.replit.app`)
3. Click **Connect** — the platform calls `/api/sources` to fetch live source status
4. In connected mode, imports go to the database (not just browser memory), Apify runs are managed server-side, and source status reflects real environment variable configuration

The live backend is optional. Keystone is fully functional in standalone mode — connected mode adds persistence and team-sharing capabilities.

---

---

## Part C: Intelligence Copilot (AI Panel)

### Overview

The Intelligence Copilot is a chat interface powered by Claude (claude-sonnet-4-20250514) with a deterministic offline fallback. It runs inside the platform, grounded in your live venue data, and answers questions about your pipeline, territories, and competitive landscape.

Access it by clicking the **sparkle ✦ icon** in the top-right of any page.

---

### What the Copilot Can Answer

| Question type | Example |
|---------------|---------|
| **Pipeline overview** | "How many venues are in the pipeline?" |
| **Top leads** | "Top 10 hot leads with emails" |
| **Venue detail** | "Tell me about Sky Zone Denver" |
| **Regional comparison** | "Compare the UK vs Germany" |
| **Competitive picture** | "Who are our biggest competitors in the US?" |
| **Market sizing** | "How big is the APAC market?" |
| **Segment breakdown** | "Which type of venue has the most whitespace?" |
| **Expansion strategy** | "Where should Tigapo expand next?" |

---

### How It Works (Technical Overview)

The Copilot uses a two-stage approach:

**Stage 1 — Deterministic analysis (instant, offline)**
Before calling the AI, the platform runs a structured `runAgentQuery()` function that classifies your question by intent and calls the relevant data tool:
- `getPipelineStats()` — for count/status/funnel questions
- `searchVenues()` — for top/best/list questions
- `getVenueDetails()` — for specific venue questions
- `compareRegions()` — for compare/vs questions
- `competitive()` — for competitor/landscape questions
- `market()` — for TAM/size/benchmark questions
- `segments()` — for category breakdown questions

This produces a structured answer in under 100ms, even with no internet connection.

**Stage 2 — Claude enrichment (when connected)**
The structured answer is combined with a real-time data digest and sent to Claude with a strict system prompt:
> *"Answer using ONLY the data snapshot and findings provided. Be concise (under 150 words unless asked for detail), concrete, and sales-oriented. Use plain text, no markdown headers. When listing venues or numbers, use the exact figures given — never invent data."*

Claude adds conversational framing, context, and strategic insight to the deterministic answer.

**Offline fallback:** If Claude is unreachable (browser not in a Claude artifact, or no API access), the deterministic answer is surfaced directly with a note: *(Offline analysis — open this platform as a Claude artifact for full AI answers.)*

---

### Suggested Prompts

The Copilot ships with five suggested prompts shown as chips:

1. **"Where should Tigapo expand next?"** — triggers competitive + regional analysis
2. **"Top 10 hot leads with emails"** — surfaces your best outreach-ready venues
3. **"Which markets have zero Tigapo presence?"** — whitespace country analysis
4. **"Summarise our UK position"** — regional competitive snapshot
5. **"Biggest whitespace opportunity"** — greenfield market identification

Click any chip or type your own question.

---

### Chat Memory

The Copilot stores the last 30 messages in browser localStorage. The conversation persists across browser restarts. This means follow-up questions work — the model has context from earlier in the session.

To clear the conversation history, close and reopen the panel, then delete via browser developer tools (localStorage key `fec:chat`), or simply start fresh with a new question.

---

### Rich Responses

The Copilot renders structured outputs inline beneath text answers:

| Output type | When shown | Interaction |
|-------------|-----------|-------------|
| **Venue list** | "Top 10 leads" type queries | Click any venue card to jump to that venue in Locations |
| **Region comparison table** | "Compare X vs Y" queries | Shows discovered count + avg score per region |
| **Segment breakdown** | "By type" queries | Shows count, avg score, whitespace % per category |
| **Venue detail card** | Single venue lookups | Click to open venue in Locations |

---

### Limitations

- The Copilot answers **only from data loaded into the platform**. It cannot search the web, access Salesforce, or look up information not already in Keystone.
- If your dataset is small (<100 venues), answers may be thin — load more data first.
- For complex multi-step analysis (e.g. "Which T3 venues in Germany on Legacy POS have email and score > 70?"), use the Locations page filters directly — they are more precise and faster for this use case.
- The Copilot has a 150-word answer cap by default. Ask for "more detail" or "full breakdown" if you need a longer answer.

---

*Keystone · by Tigapo · Confidential*
