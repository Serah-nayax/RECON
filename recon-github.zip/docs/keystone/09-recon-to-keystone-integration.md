# 09 · Recon → Keystone Integration

**Keystone · by Tigapo — Internal Documentation**

---

## The Pipeline

```
RECON                           KEYSTONE
─────────────────────────────   ─────────────────────────────────────
1. Run a Maps Search            4. Import the CSV into Sources
   (territory + keyword)            → venues appear on the map
        ↓                           → pipeline is populated
2. Enrich the batch                 → scoring runs automatically
   (AI scoring, contacts,           → Locations page is ready
    competitive intel)
        ↓
3. Filter to QUALIFY leads
   → Export batch as CSV
```

**Recon is the discovery and qualification engine. Keystone is the map, pipeline, and outreach engine.** You fill Keystone from Recon — not the other way around.

---

## Step 1 — Discover Venues in Recon

### Option A: Maps Search (new territory from scratch)

1. Open **Recon → Maps Search**
2. Enter a keyword: `arcade`, `family entertainment center`, `trampoline park`, `laser tag`, `bowling`
3. Enter a location: city, metro area, or country
4. For large areas: enable **Grid mode** — divides the area into cells for complete coverage
5. Click **Search**

Recon pulls every matching venue from Google Maps with:
- Business name, address, city, state, country
- Phone number
- Star rating + review count
- Website URL
- Google Maps category
- Latitude / longitude

### Option B: Lead List Upload (existing list)

1. Open **Recon → Lead Qualifier**
2. Upload a CSV of businesses (must have a `website` URL column — Recon crawls each site)
3. Map columns → **Import**

---

## Step 2 — Enrich and Qualify in Recon

Once venues are in the Lead Qualifier, Recon runs its full enrichment pipeline on each one:

- Crawls the venue website (up to 12 pages)
- Scrapes Google / Yelp / TripAdvisor reviews
- Finds social profiles (Facebook, Instagram, LinkedIn)
- Pulls decision-maker contacts via Seamless.AI (name, title, direct email, direct phone, LinkedIn)
- AI scoring via Gemini (0–100 score, QUALIFY/BORDERLINE/DISQUALIFY verdict)
- Competitive system identification (what POS/booking system they run, with evidence)
- Outreach hook via Claude (personalised opening line per venue)

**This takes 3–5 minutes per lead in parallel.** A batch of 50 venues takes ~20–30 minutes total.

---

## Step 3 — Filter to QUALIFY Leads and Export

When the batch completes:

1. In **Recon → Lead Qualifier**, filter the batch results to **QUALIFY** (green)
   - Optional: also include **BORDERLINE** venues you want to track in Keystone
2. Click **Export CSV** on the filtered results

The exported CSV contains:

| Column | Description | Used by Keystone |
|--------|------------|-----------------|
| `name` | Business name | ✅ Venue name |
| `city` | City | ✅ Location |
| `state` | State / region | ✅ Location context |
| `country` | Country | ✅ Location + map filter |
| `website` | Business website URL | ✅ Enrichment + tech detection |
| `phone` | Phone number | ✅ Contact |
| `email` | Verified email (from Seamless.AI) | ✅ Contact |
| `contactName` | Decision-maker full name | ✅ Owner name |
| `contactLinkedIn` | LinkedIn URL | ✅ Owner LinkedIn |
| `rating` | Google star rating | ✅ Scoring signal |
| `reviewCount` | Total review count | ✅ Scoring signal |
| `category` | Google Maps category | ✅ ICP classification |
| `lat` | Latitude | ✅ Precise map pin |
| `lng` | Longitude | ✅ Precise map pin |
| `posSystem` | Detected POS system | ✅ Competitive classification |
| `recon_score` | Recon AI score (0–100) | Reference only |
| `recon_verdict` | QUALIFY / BORDERLINE / DISQUALIFY | Reference only |

> **Export just QUALIFY leads** unless you intentionally want BORDERLINE venues in your pipeline for monitoring. DISQUALIFY leads should not be imported into Keystone — they add noise and dilute the pipeline.

---

## Step 4 — Import into Keystone

1. Open **Keystone**
2. Navigate to **Sources** in the sidebar
3. Scroll to **Venue universe — import CSV**
4. Click **Choose file** → select the Recon export CSV
5. The preview shows:
   - How many rows will be added as new venues
   - How many match existing records (will be updated, not duplicated)
   - Which columns were auto-detected
6. Click **Import**

**What happens immediately after import:**

| What Keystone does | Result |
|-------------------|--------|
| Reads `lat`/`lng` columns | Venues appear as precise pins on the map |
| Reads `rating` + `reviewCount` | Scoring signals populated |
| Reads `email`, `phone`, `contactLinkedIn` | Contact fields populated — enrichment score calculated |
| Reads `posSystem` | Competitive classification assigned (Legacy / Specialist / Horizontal / Whitespace) |
| Reads `category` | ICP matching run — in-ICP venues get +6 to score |
| Applies scoring algorithm | All imported venues move to **Scored** status with a 0–100 lead score |
| Places on map | Pins appear immediately in Score mode, coloured by tier |

---

## Step 5 — Work the Pipeline in Keystone

Imported venues from Recon arrive as **Scored** status — they've been enriched by Recon, so they skip the Raw → Enriched stages.

**Immediately useful views:**

**Map → Score mode**
Your Recon QUALIFY leads appear as green (80+) and blue (60–79) pins on the map. The geographic distribution of your qualified pipeline is visible at a glance.

**Map → Rivals mode**
Pins coloured by competitive situation. Venues where Recon identified a Legacy POS appear red — your displacement campaign targets.

**Locations page**
Sorted by lead score by default. The email, phone, owner name, and LinkedIn from Recon's Seamless.AI enrichment are already populated. The outreach message generator has what it needs.

**Pipeline board**
All imported venues appear in the **Scored** column. Move them to **Qualified** as you review, **Exported** after you send to CRM, **Disqualified** if they're not a fit on closer inspection.

---

## Column Name Mapping Reference

If Recon's export headers don't exactly match what Keystone expects, use this reference to rename columns before importing:

| If Recon exports this | Rename to | Notes |
|-----------------------|-----------|-------|
| `businessName` | `name` | Some Recon export formats use `businessName` |
| `websiteUrl` | `website` | |
| `phoneNumber` | `phone` | |
| `emailAddress` | `email` | |
| `ownerName` or `contactName` | `ownerName` | |
| `linkedinUrl` or `contactLinkedIn` | `ownerLinkedIn` | |
| `googleRating` | `rating` | |
| `reviewTotal` | `reviewCount` | |
| `businessCategory` | `categories` | Keystone expects comma-separated if multiple |
| `latitude` | `lat` | |
| `longitude` | `lng` | |
| `detectedPos` or `posSystem` | `posSystem` | |

**Quick fix in Excel/Google Sheets:**
- Row 1 = headers → rename the cells that don't match
- Save as CSV → import to Keystone

---

## Practical Example — Qualifying Sydney, Australia

**In Recon:**
1. Maps Search → keyword: `arcade` → location: `Sydney, Australia`
2. Grid mode: 3×3 (9 cells) for complete metro coverage
3. Result: 87 venues returned
4. Enrich all 87 → wait 25 minutes
5. Filter to QUALIFY: 23 venues
6. Export as CSV

**In Keystone:**
1. Sources → Import CSV → select the 23-venue export
2. Map → Score mode → zoom to Sydney → 23 green/blue pins appear
3. Locations → sorted by score → top 5 are A-tier (score 80+)
4. All 5 have email + phone from Recon's Seamless.AI enrichment
5. Outreach messages are pre-drafted and ready to personalise

**Time from search to outreach-ready: ~35 minutes.**

---

## Common Questions

**"Should I import BORDERLINE leads?"**
Only if you want to monitor them — e.g. a venue that scores 58 because machine count isn't confirmed on the website. Import them and set the status to Monitor. Once you call and confirm they're a fit, advance to Qualified in Keystone.

**"Does importing update existing venues or create duplicates?"**
Keystone deduplicates on `name + country` (case-insensitive). If a venue is already in Keystone, the import **updates** it with Recon's data (better contacts, confirmed POS). It does not create a second record.

**"Can I import directly from Recon's Maps Search before enrichment?"**
Yes — export from Maps Search before hitting the Lead Qualifier, and Keystone will import them as **Raw** status. They'll show on the map (if lat/lng is included) but won't have contacts or scoring yet. Useful if you want the full map populated immediately while enrichment runs in Recon.

**"The lat/lng columns are blank — venue pins are going to the country centre"**
Recon's Maps Search export includes lat/lng from Google Maps data. If you're importing from a Lead List Upload (your own CSV), those coordinates may be missing. Use Keystone's geocoder: Sources → Geocode addresses → runs Nominatim or Mapbox to place precise pins.

**"Which ICP should I use in Recon for FEC prospecting?"**
Use the FEC ICP configured for Nayax/Tigapo (T3 Flagship focus). It should qualify on: machine count 15+, redemption counter, token/card payment system, staffed operation. Venues that QUALIFY under this ICP map directly to Keystone's T3 Flagship tier. See `02-icp-library.md` in the Recon documentation for ICP setup.

---

## What Recon Adds That Keystone Can't Do Alone

| Data point | How Recon gets it | Available in Keystone after import |
|-----------|------------------|-----------------------------------|
| Decision-maker name | Seamless.AI contact lookup | `ownerName` field |
| Direct email | Seamless.AI verified email | `email` field → outreach ready |
| Direct phone | Seamless.AI direct dial | `phone` field |
| LinkedIn URL | Seamless.AI contact data | `ownerLinkedIn` → click-to-connect |
| POS system confirmed | Website crawl evidence | `posSystem` → competitive class + map colour |
| Review pain points | Google/Yelp/TripAdvisor scrape | Informs outreach hook (use Recon before calling) |
| AI-scored ICP fit | Gemini scoring on full website content | Recon score is your confidence check on Keystone's rule-based score |

---

*Keystone · by Tigapo · Confidential*
