# 03 · Map

**Keystone · by Tigapo — Internal Documentation**

---

## Overview

The Map page is the fastest way to understand a territory. Every loaded venue is pinned on a dark cartographic canvas — zoom anywhere, drill into clusters, click venues for instant detail, and switch between five analytical lenses in real time.

---

## Opening the Map

Click **Map** in the left sidebar. The map initialises at a world view and renders all loaded venues as clustered pins on a dark carto basemap.

---

## The Five Map Modes

Switch modes using the button strip at the top of the map. Each mode recolours pins and clusters to answer a different question. The **legend** at the bottom-left changes dynamically to match the active mode — always check it when switching.

---

### Mode 1 — Score (default)

**Question answered: Where are the highest-quality leads?**

Pins are coloured by lead score tier:

| Colour | Score range | Priority |
|--------|------------|---------|
| 🟢 Green | 80–100 | Hot — call now |
| 🔵 Blue | 60–79 | Warm — nurture within 5 days |
| 🟡 Amber | 40–59 | Cold — monitor |
| 🟣 Violet | 20–39 | Low priority |
| ⚫ Grey | 0–19 / unscored | No action |

Cluster colours reflect the **dominant tier** within the cluster. A green cluster means most venues inside are high-scoring. Drill down by clicking the cluster.

**Use this for:** Territory prioritisation. Identify dense green clusters in your region before building your call list.

---

### Mode 2 — Tigapo

**Question answered: Where are Tigapo's customers and where is there whitespace?**

| Pin type | Meaning |
|----------|---------|
| 🔷 Cyan pulsing dot | Tigapo customer — already installed |
| ⚫ Grey pin | Prospect — not yet a customer |

**Use this for:** Understanding penetration density. A region with many grey pins near cyan ones = expansion opportunity where Tigapo has proven local presence. A region with all grey = greenfield entry.

---

### Mode 3 — Rivals

**Question answered: What POS system is everyone running?**

Pins are coloured by competitive classification:

| Colour | Classification | Sales motion |
|--------|---------------|-------------|
| 🔷 Cyan (pulsing) | Tigapo installed | Already won |
| 🟢 Green | Whitespace — no POS detected | Greenfield — land and expand |
| 🔴 Red | Legacy POS (Siriusware / Centaman / Clover) | Displace — migration pitch |
| 🟣 Violet | FEC Specialist (ROLLER / Embed / Semnox / CenterEdge etc.) | Competitive displacement |
| 🔵 Blue | Horizontal POS (Lightspeed / Square / Shopify) | Upgrade play |

**Use this for:** Pre-territory entry. Before calling into a new market, switch to Rivals mode to understand what you're walking into. Dense red = displacement campaign opportunity. Dense green = land-and-expand greenfield.

---

### Mode 4 — Density

**Question answered: Where are the highest concentrations of FEC venues, regardless of score?**

A **heatmap overlay** is applied over the standard pins. Bright red/yellow areas = high venue concentration. Cooler blue/purple areas = sparse.

**Use this for:** Finding high-density urban markets that aren't yet represented in your qualified pipeline. A high-density area with few Qualified-status pins means discovery has happened but reps haven't worked it yet.

---

### Mode 5 — Markets

**Question answered: How big is each country as a market, and what is Tigapo's penetration?**

One **bubble per country** is displayed. Bubbles are:
- **Sized** by annual market revenue (bigger bubble = larger market)
- **Coloured** by Tigapo penetration tier:
  - 🔴 Red = no Tigapo presence (whitespace market)
  - 🟡 Amber = low penetration (< 10%)
  - 🟢 Green = established presence (≥ 10%)

> **Requires the arcade market dataset.** Load the country-level CSV in Sources → Country market data. Without it, this mode shows a blank map.

**Use this for:** Global expansion planning and leadership briefings. The map immediately shows where Tigapo has gravity vs. where the opportunity is completely untapped.

---

## Filter Controls

The filter bar sits above the map (overlaid on the top-left). Filters combine — apply multiple at once.

| Filter | Options | Effect |
|--------|---------|--------|
| **Venue search** | Text input — name, city, or country | Pan and highlight matching venues; dim others |
| **Country dropdown** | Select from all countries in dataset | Show only venues in the selected country |
| **Min score slider** | 0 / 20 / 40 / 60 / 80 | Hide all venues below the selected score threshold |

**Min score slider practical use:** Set to **80** before a session to show only hot leads on the map — dramatically reduces visual noise and focuses attention on investable targets.

---

## Live Stat Chips (Top Right)

Three chips update in real time as you pan, zoom, and filter:

| Chip | What it shows |
|------|--------------|
| **Total venues** | Count of all venues currently visible in the viewport |
| **Tigapo customers** | Count of customer-status venues in the viewport |
| **Hot leads (80+)** | Count of score ≥ 80 venues in the viewport |

As you pan and zoom, the numbers update instantly. Use these to compare territories at a glance without switching pages — zoom into Germany, read the chips; zoom into France, compare.

---

## Venue Pop-up

Click any individual pin (once clusters are expanded) to open a pop-up showing:

| Field | Description |
|-------|------------|
| **Name** | Venue name (bold) |
| **Location** | City, country |
| **Status badge** | Current pipeline stage |
| **Score pill** | Lead score (0–100, colour-coded) |
| **Rating + reviews** | Star rating and review count (e.g. ★ 4.6 · 284 reviews) |
| **Tigapo highlight** | If installed: "Tigapo customer · N machines" |
| **Verified email** | Email address if enriched (masked for privacy in demo mode) |
| **POS system** | Detected system or "No POS — Whitespace" |
| **Booking system** | Detected booking platform or "No booking" |
| **Score brief** | One-sentence AI summary of fit and gaps (e.g. "Strong fit (A). Email found; 284 reviews; Legacy POS — displacement opportunity.") |
| **Google Maps** | Opens venue in Google Maps in a new tab |
| **Website** | Opens venue website in a new tab (if available) |
| **View in Locations** | Deep-links to the full Locations detail panel for this venue |

---

## Market Pop-up (Markets Mode Only)

In **Markets mode**, clicking a country bubble opens a dedicated market pop-up:

| Section | Content |
|---------|---------|
| **Country name + flag** | Country and emoji flag |
| **Continent** | Continental grouping |
| **Venue count** | Discovered FEC venues in this country |
| **Market revenue** | Annual market revenue (USD) |
| **Tigapo penetration %** | Installs ÷ total venues |
| **Tigapo installed panel** | If Tigapo is present: list of venue names and machine counts |
| **Open Market panel** | If no Tigapo presence: "X venues — open market" |
| **Payment systems** | Incumbent payment/POS systems in use in this country |
| **Market intelligence note** | Country-specific context note (if loaded from market dataset) |

Use the Market pop-up for quick country-level briefings before a call with regional leadership or a prospect in a new country.

---

## Legend

The **legend** floats at the **bottom-left** of the map. It changes dynamically every time you switch modes:

| Mode | Legend shows |
|------|-------------|
| Score | Score tier colours (Green 80+ / Blue 60–79 / Amber 40–59 / Violet 20–39 / Grey <20) |
| Tigapo | Cyan pulsing = customer / Grey = prospect |
| Rivals | Classification colours (Cyan/Green/Red/Violet/Blue) |
| Density | Heatmap intensity scale |
| Markets | Penetration tier colours (Red / Amber / Green) |

---

## Cluster Behaviour

Clusters aggregate nearby pins automatically at each zoom level. The cluster badge shows:
- **Count** of venues in the cluster
- **Colour** reflecting the dominant tier (most common category within the cluster)

Five cluster colour types match the active mode's colour scheme. Clicking a cluster zooms in one level; keep clicking to drill to individual pins.

---

## Practical Scenarios

### "I'm covering the Southeast US this quarter — where do I start?"

1. Map → **Score mode** + Country = United States
2. Drag min score slider to **60**
3. Find the densest blue/green cluster in the Southeast
4. Switch to **Rivals mode** — identify red (legacy) venues in the same area
5. Read the stat chips: how many hot leads visible?

### "My VP asked what our competitive position is in Germany"

1. Map → **Rivals mode**
2. Country filter = Germany
3. Read the chip: how many venues visible? What colour dominates?
4. Switch to **Markets mode** — click Germany bubble for market revenue + penetration

### "Show me where we can expand with minimum competitive friction"

1. Map → **Rivals mode**
2. Zoom out to world view
3. Look for dense **green** (whitespace) clusters — no competitors, no incumbents
4. Filter: min score **60** — confirms those green clusters also have quality prospects

---

## Tips for Demo Situations

- Open in **Score mode** at world view — immediately shows the scale of the opportunity
- Zoom into the prospect's country slowly — builds anticipation
- Switch to **Tigapo mode** to show where Tigapo already has gravity (and where whitespace surrounds it)
- Click a high-score green pin near their location → read the score brief aloud
- Finish with **Markets mode** → click their country bubble → market revenue + penetration story

---

*Keystone · by Tigapo · Confidential*
