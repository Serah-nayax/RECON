# 07 · Scoring & Competitive Reference

**Keystone · by Tigapo — Internal Documentation**

---

## Overview

Complete reference for every scoring signal, every competitive classification, and every operator tier definition. Use this to explain a score to a manager, audit a venue's classification, or prepare for a call where you need to cite exact numbers.

---

## Enrichment Score Reference (0–100)

The Enrichment Score measures **contact completeness** — how much raw data is available on this venue. It is calculated immediately after enrichment runs, before lead scoring.

| Signal | Points | Trigger |
|--------|--------|---------|
| Email verified | +30 | A verified, deliverable email is confirmed |
| Phone found | +20 | A direct business phone number is present |
| Owner LinkedIn | +25 | A decision-maker LinkedIn profile URL found |
| Tech stack detected | +15 | Any POS, booking, or platform technology identified |
| Website present | +10 | A business website URL confirmed |
| **Maximum** | **100** | |

Use Enrichment Score to identify which venues in a territory need another enrichment pass before scoring — a venue scoring < 40 enrichment score has significant gaps.

---

## Lead Score Reference (0–100)

The Lead Score measures **sales opportunity and outreach readiness**. It is calculated by applying rule-based weights to enrichment signals.

### Complete Signal Table

| Signal | Points | Why it matters |
|--------|--------|----------------|
| Has website | +10 | Operational maturity — not cash-only |
| Email found | +20 | Reachable — outreach is possible |
| Phone verified | +8 | Direct contact path |
| Owner on LinkedIn | +10 | Decision-maker identifiable |
| 100+ reviews | +14 | High-volume venue — bigger deal size |
| Rating ≥ 4.3★ | +10 | Well-run operation — more likely to invest |
| POS system detected | +8 | Has technology budget |
| Legacy POS (Siriusware / Centaman / Clover) | +8 | Active displacement opportunity — stacks with POS detected |
| Has POS but no booking system | +10 | Clear upsell gap — first deal with no displacement |
| Booking system present | +6 | Operationally sophisticated |
| In core ICP categories | +6 | Strong product fit |
| Outside core ICP | −6 | Weaker fit — deprioritise |

**Maximum achievable raw score: ~110, normalised to 100.**

### Score Tiers

| Score | Tier | Sales action |
|-------|------|-------------|
| 80–100 | **A — Hot** | Call now — immediate personal outreach |
| 60–79 | **B — Warm** | Nurture — sequence within 5 business days |
| 40–59 | **C — Monitor** | Qualification call in 30 days |
| 0–39 | **D — Low** | Bulk email or disqualify |

---

## Model Confidence Reference (0.00 – 0.97)

The confidence score runs alongside the lead score. It measures **how much to trust the score** — driven by data volume and completeness, not opportunity size.

### Confidence Formula

| Component | Contribution |
|-----------|-------------|
| Base (all venues) | 0.45 |
| Review volume | +0.00 to +0.30 (scales linearly, caps at ~1,500 reviews) |
| Email verified | +0.08 |
| Owner LinkedIn found | +0.07 |
| POS system detected | +0.06 |
| In ICP | +0.05 |
| **Maximum** | **0.97** |

### Confidence Interpretation Guide

| Confidence | Meaning | Recommended action |
|------------|---------|-------------------|
| ≥ 0.85 | High — strong data foundation. Score is reliable. | Act on it directly. |
| 0.65–0.84 | Good — most signals present. Minor gaps. | Proceed with awareness of gaps. |
| 0.50–0.64 | Moderate — some key signals missing. | Verify on a quick discovery call before investing time. |
| < 0.50 | Low — sparse data. Score extrapolated from few signals. | Treat as untested; confirm category and fit first. |

### When to Distrust a Score

A high score with low confidence is a **false positive risk**. Common causes:

- **Very few reviews (< 10):** The +14 review signal isn't triggered, and the base confidence is low. The venue may be newly opened or niche.
- **No website:** The tech-stack and POS detection algorithms rely partly on website fingerprinting. A venue with no website has no POS signal — the score may undercount opportunity.
- **Rare category:** If the category doesn't match any ICP keyword, the ICP signals (±6) may be assigned incorrectly. A "laser tag + escape room" combo venue may be misclassified.
- **Duplicate records:** If the same venue appears twice with slightly different names or geocodes, scores may diverge between the duplicates. Merge duplicates before qualifying.

---

## How to Calibrate Scores for a New Region

Before prospecting a new geography, run this calibration sequence:

1. **Open Dashboard → Market Benchmarks** for the target region
2. Note the benchmark: avg rating, % with email, % with POS
3. Apply a country filter in Locations to see only that region
4. Check: does your dataset's email % match the benchmark? If your dataset shows 15% email and the benchmark is 45%, your enrichment for that region is incomplete — run Apollo enrichment before scoring matters
5. Check avg score in the region vs. the global average. If it's significantly lower, the region may have less data available (lower reviews, fewer websites) — apply a confidence-adjusted threshold: don't call_now until confidence ≥ 0.75 in a data-sparse market
6. Check the dominant competitive class in the region (Rivals mode on Map). A Legacy-heavy region needs a different pitch than a Whitespace-heavy one

---

## Priority Score Reference (CRM Export Ranking, 0–100)

Priority Score is used for CRM export ordering only. It weights deal size and strategic value — not outreach ease.

### Complete Priority Score Formula

| Component | Detail | Points |
|-----------|--------|--------|
| **Base** | All venues | 28 |
| **Tier T3** | 15+ machines or redemption flag | +22 |
| **Tier T2** | 3–15 machines | +12 |
| **Tier T1** | 1–5 machines | +4 |
| **Legacy POS** | Siriusware / Centaman / Clover | +20 |
| **Whitespace** | No POS detected | +16 |
| **Horizontal POS** | Lightspeed / Square / Shopify | +14 |
| **Specialist POS** | ROLLER / Embed / Semnox / CenterEdge / Sacoa / Intercard | +9 |
| **Email present** | Verified email on file | +10 |
| **Website present** | Confirmed website | +4 |
| **Machine count bonus** | Per machine, capped | max +12 |
| **150+ reviews** | Scale indicator | +4 |
| **Maximum** | | **~100** |

### Why Priority Score Differs from Lead Score

Lead Score = how easy is it to reach and how good is the opportunity?
Priority Score = how big is the deal and how urgent is the competitive play?

A T3 Flagship on Legacy POS is urgently important (Priority Score ~90) even if the rep hasn't found an email yet (Lead Score ~55). A T1 Unattended venue might score 72 on Lead Score (has email, website, good reviews) but only 48 on Priority Score (small deal). CRM should queue the T3 first; the rep's daily call list should prioritise the T1 (more reachable).

---

## Competitive Classifications — Decision Tree

```
Is the venue a Tigapo customer?
   YES → Customer (excluded from competitive scoring, cyan on map)
   NO  ↓

Does the venue have a detected POS system?
   NO  → WHITESPACE (greenfield)
   YES ↓

Is the POS system in the LEGACY list?
   YES → LEGACY
   NO  ↓

Is the POS system in the SPECIALIST list?
   YES → SPECIALIST
   NO  → HORIZONTAL
```

### Legacy Systems (Displacement Priority — Map: Red)

| System | Notes |
|--------|-------|
| **Siriusware** | Legacy FEC/ski/bowling management. End-of-life trajectory. Strong migration argument. |
| **Centaman** | Legacy attractions/FEC management. Common in older independents. |
| **Clover** | Square-like horizontal POS often used by small FECs on a budget. Not FEC-native. |

**Sales motion:** Migration pitch. ROI on modernisation (Nayax hardware, cashless, cloud reporting vs. on-premise pain). Reference the 3–5 year cost comparison.

### Specialist Systems (Competitive Displacement — Map: Violet)

| System | Notes |
|--------|-------|
| **ROLLER** | Australian-origin cloud FEC platform. Strong in trampoline parks and bowling. Booking-first. |
| **Embed** | FEC-focused POS, strong in card-based cashless. Direct competitor. |
| **Semnox** | India-origin RFID-based FEC management. Strong in redemption. |
| **CenterEdge** | US FEC platform. Common in mid-sized family entertainment. |
| **Sacoa** | Latin-America-origin cashless card system. Strong in LATAM. |
| **Intercard** | Legacy RFID card system. Often hardware-focused. |
| **Intacard** | UK/Europe cashless. Similar to Intercard. |
| **Gantner** | European RFID/locker/access management. Overlaps with Sacoa in EMEA. |
| **Coredy** | Smaller FEC software platform. |

**Sales motion:** Differentiate on integrated payments + Nayax hardware. Know which competitor before the call — ROLLER venues often lack cashless depth; Semnox venues often want cloud-first.

### Horizontal Systems (Upgrade Play — Map: Blue)

| System | Notes |
|--------|-------|
| **Lightspeed** | Restaurant/retail POS. Common in hybrid venues (bowling + bar). |
| **Square** | Consumer-grade POS. Very common in small-to-mid venues. |
| **Shopify** | E-commerce/retail. Occasionally seen in FEC gift shops. |

**Sales motion:** Frame as an upgrade, not a replacement fight. Everything Tigapo does that their current system doesn't — redemption, token management, RFID wristbands, party booking, cashless.

### Whitespace — Greenfield (Map: Green)

No detectable POS. Managing cash, consumer card reader, or no formal system.

**Sales motion:** Education-first. Start with what a POS + cashless gives them (visibility, upsell, labour savings, reduced cash shrinkage). Land small, expand fast.

---

## Operator Tier Definitions and Inference Rules

### T1 · Unattended (1–5 machines)

**Detection signals:**
- Machine count 1–5 in enrichment data
- No "redemption" or "prize counter" keyword
- No dedicated staffing signals
- Often: `kiddie rides`, `claw machine`, `vending`, `coin-op`

**Profile:** Arcade corner inside bowling alley, restaurant, cinema, retail centre. Vending-style. ACV $5K–$20K.

### T2 · Semi-attended (3–15 machines)

**Detection signals:**
- Machine count 3–15
- Mixed category signals (bowling + arcade, trampoline + birthday party)
- Some booking signals — basic reservation software

**Profile:** Dedicated FEC section with partial staffing. ACV $15K–$60K.

### T3 · Flagship (15+ machines, or redemption override)

**Detection signals (any one triggers T3):**
- Machine count > 15
- `redemption` keyword in categories, description, or name
- `prize counter`, `ticket redemption` in any field
- Party/event booking system present
- 150+ Google reviews (high throughput)

**Redemption override:** A venue with 12 machines but a confirmed redemption counter is classified as T3. Redemption presence is a stronger indicator than raw machine count — it signals a fully-staffed, full-service FEC operation.

**Profile:** Dedicated FEC, purpose-built. ACV $40K–$200K+.

---

## ICP Definition

**In ICP (adds +6 to Lead Score):**
- Arcades and FECs (primary)
- Trampoline parks with arcade or redemption sections
- Bowling alleys with 5+ amusement machines
- Indoor play centres with token or card systems
- Go-kart tracks with arcade annexe
- Laser tag venues with redemption or full FEC operations

**Outside ICP (subtracts −6 from Lead Score):**
- Pure bowling (no machines)
- Pure cinema, restaurant, or bar (no machines)
- Pure escape rooms (no machines)
- Pure sports facilities
- Mini golf only (no token/card system)
- Pure retail (no entertainment)

ICP status affects Lead Score only — it does not automatically disqualify a venue. Use judgment on outside-ICP venues with high overall scores.

---

## Using Scores in Sales Conversations

**Do** use scores as an internal routing and prioritisation tool.

**Do not** quote the score to a prospect. ("You scored 84 in our system" is not a useful opening.)

**Do** use score components as conversation hooks:

| Score component | Conversation hook |
|----------------|------------------|
| High email score | You have their contact → reach out directly |
| Legacy POS signal | Lead with migration story |
| No booking | Lead with the booking upsell |
| 100+ reviews | "You're clearly a serious operator — I want to show you what operators at your scale use for..." |
| High confidence (≥ 0.85) | Trust the score — proceed without additional qualification calls |
| Low confidence (< 0.55) | Run a discovery call first to validate the score before investing in a full proposal |

The score tells you **what conversation to have** — not just whether to have it.

---

*Keystone · by Tigapo · Confidential*
