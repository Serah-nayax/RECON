# 04 · Pipeline

**Keystone · by Tigapo — Internal Documentation**

---

## Overview

The Pipeline page is the sales engine. Every venue in Keystone is tracked through six stages on a Kanban board — from raw import through to CRM export. This is where enrichment happens, scores are generated, and qualified leads are prepared for outreach.

---

## The Six Pipeline Stages

| Stage | Badge colour | What it means | Typical next action |
|-------|-------------|---------------|---------------------|
| **Raw** | Grey | Scraped from Google Maps — name, address, phone, category, rating/reviews | Enrich |
| **Enriched** | Green | Email, owner LinkedIn, POS/booking system detected, enrichment score calculated | Review enrichment, then Score |
| **Scored** | Violet | Rule-based 0–100 score + tier (A/B/C/D) applied | Qualify or disqualify |
| **Qualified** | Amber | Sales-ready — rep has reviewed and confirmed fit | Export to CRM or begin outreach |
| **Exported** | Cyan | Pushed to Salesforce / HubSpot / CSV | In active outreach |
| **Disqualified** | Red | Not a fit — permanently excluded from active pipeline | — |

---

## What Enrichment Does — The Apify Stack

When an enrichment run executes, it processes each venue through a layered pipeline. Each layer adds data and has a cost:

| Layer | What it adds | Cost / 1,000 records |
|-------|-------------|----------------------|
| Base scrape | Place name, address, phone, opening hours, categories, ratings | $1.50 |
| Relevance filter | FEC keyword & category filter — removes non-FEC results | $0.53 |
| Additional place details | Website, popular times, business attributes | $1.05 |
| Company contacts | Owner name, title, LinkedIn URL | $1.05 |
| Business leads | Verified email, direct phone, company size | $4.00 |
| Email verification | Deliverability check — removes bounces before you send | $2.00 |
| Social media | Facebook & Instagram profile URLs | $6.00 |
| **Total** | **Full enrichment stack** | **$16.13 / 1,000 = $0.054 per lead** |

All enrichment runs **inside a single Apify actor** — zero external API accounts, one bill, one place to manage tokens.

---

## Enrichment Score (0–100)

After enrichment, each venue receives an **Enrichment Score** measuring contact completeness. This is distinct from the Lead Score (which measures sales opportunity):

| Signal | Points |
|--------|--------|
| Email verified | +30 |
| Phone found | +20 |
| Owner LinkedIn | +25 |
| Tech stack detected (POS / booking / platform) | +15 |
| Website present | +10 |
| **Maximum** | **100** |

A venue with email + phone + LinkedIn + tech stack + website scores 100 — it's fully enriched. A venue with only phone + website scores 30 — still useful but lacking key contact signals.

---

## Lead Score (0–100) — Every Signal and Its Weight

The rule-based Lead Score measures **sales opportunity**. Every signal and its exact weight:

| Signal | Points | Why it matters |
|--------|--------|----------------|
| Has website | +10 | Indicates operational maturity |
| Email found | +20 | Reachable — outreach possible |
| Phone verified | +8 | Direct contact path |
| Owner on LinkedIn | +10 | Decision-maker identifiable |
| 100+ reviews | +14 | High-volume venue — bigger deal size |
| Rating ≥ 4.3★ | +10 | Well-run — more likely to invest in tech |
| POS system detected | +8 | Has a budget for technology |
| Legacy POS (Siriusware / Centaman / Clover) | +8 | Active displacement opportunity — stacks with POS detected |
| Has POS but no booking system | +10 | Clear upsell gap |
| Booking system present | +6 | Operationally sophisticated |
| In core ICP categories | +6 | Strong product fit |
| Outside core ICP | −6 | Weaker fit — deprioritise |

**Maximum raw score: ~110, normalised to 100.**

---

## Score Tiers (A / B / C / D)

| Score | Tier | Label | Recommended action |
|-------|------|-------|-------------------|
| 80–100 | **A** | Hot | Call now — strong fit, reachable, clear product gap |
| 60–79 | **B** | Warm | Nurture — good fit, may need more contact info |
| 40–59 | **C** | Monitor | Moderate fit, needs qualification call |
| 0–39 | **D** | Low priority | Limited contactability or weak ICP match |

---

## Recommended Action Field

After scoring, every venue is assigned a `recommendedAction` field — your automated daily work queue:

| Action | Trigger condition | What to do |
|--------|-----------------|-----------|
| `call_now` | Score ≥ 80 | Immediate personal outreach this week |
| `nurture` | Score 60–79 | Add to sequence within 5 business days |
| `monitor` | Score 35–59 | Revisit in 30 days; check for new enrichment |
| `disqualify` | Score < 35 | Move to Disqualified unless there's a specific reason to keep |

The Recommended Action field is visible on the Kanban card, the Locations table, and the venue detail panel. Use it to sort your daily work queue without having to interpret scores manually.

---

## Model Confidence Score (0.00 – 0.97)

Every scored venue receives a **confidence score** alongside the lead score. Confidence reflects how reliable the score is — not how good the lead is.

Confidence is calculated from:

| Component | Contribution |
|-----------|------------|
| Base (minimum) | 0.45 |
| Review volume | Up to +0.30 (scales with review count up to ~1,500) |
| Email verified | +0.08 |
| Owner LinkedIn found | +0.07 |
| POS system detected | +0.06 |
| In ICP | +0.05 |
| **Maximum** | **0.97** |

**What to do with confidence:**

| Confidence | Interpretation | Action |
|------------|---------------|--------|
| ≥ 0.85 | Trust the score — high data quality | Act on it |
| 0.65 – 0.84 | Reasonable confidence | Proceed with awareness |
| 0.50 – 0.64 | Moderate — some signals missing | Verify on a discovery call before investing time |
| < 0.50 | Low — very few reviews, no website, rare category | Treat as untested; confirm fit before prioritising |

> **When to distrust a score:** A venue with a score of 85 but confidence of 0.48 is likely a newly-opened venue with few reviews, no website, and undetected category data. The signals that generated the 85 may be incomplete. Always cross-reference confidence before booking a call based purely on a high score.

---

## Review Sentiment Summary

Every enriched venue receives an auto-generated **sentiment summary** — a one-liner derived from the star rating and review count, framed as a Tigapo pitch angle:

| Rating | Example sentiment |
|--------|-----------------|
| < 10 reviews | *"Too few reviews to read sentiment — verify on a discovery call."* |
| ≥ 4.5★ with 100+ reviews | *"Guests rave about the experience (4.7★, 312 reviews). Peak-hour wait times surface as the main friction — a throughput/booking gap Tigapo addresses."* |
| 4.0–4.4★ with 100+ reviews | *"Solid reputation (4.2★, 148 reviews). Reviews mention checkout/queue delays and clunky booking — operational pain Tigapo solves."* |
| < 4.0★ with 100+ reviews | *"Mixed reviews (3.8★, 203 reviews) citing slow service and payment issues — strong modernization case for a unified POS."* |

Use the sentiment line as an **opening hook framing** — you're not reading reviews, you're translating public data into a pitch angle. The rep adds the specific pitch; the platform provides the insight.

---

## Tech Gap Signals

The scoring engine automatically flags specific technology gaps for each venue. These are displayed on the Kanban card and detail panel:

| Tech gap flag | Trigger | Pitch angle |
|--------------|---------|------------|
| `Legacy POS detected` | POS system is Siriusware, Centaman, or Clover | Migration pitch — lead with Nayax + modern payments |
| `No online booking system` | POS present but no booking | Upsell — fast first deal with no displacement needed |
| `No website — likely cash-only / offline ops` | No website detected | Education-first — show what visibility and digital ops give them |
| `No detectable POS — greenfield` | No POS, has website | Land-and-expand — start with POS + booking |

Tech gap flags are also used as **filters** in the Locations page — e.g. filter for `Legacy POS detected` + `Has email` to build a batch displacement outreach list.

---

## The Kanban Board

Each pipeline stage is a column. Each venue is a card. Cards show:
- Venue name (bold)
- City + country
- Lead score pill
- Recommended action
- POS system or "Whitespace" badge
- Tech gap flags

**Moving cards:** Drag any card to a different column. The destination column highlights with a dashed blue border when you hover over it. Release to drop.

Every status change is **immediately recorded in the shared team activity feed** — timestamped and attributed to the rep who made the move (based on the name set in Settings).

---

## Team Activity Feed

The activity feed (accessible from the sidebar or as a panel on the Dashboard) records every pipeline status change across the team:

```
Sarah Chen  advanced Galaxy FEC → Qualified  ·  2 min ago
James Patel  disqualified Laser Zone Tampa   ·  1 hr ago
Tom Walsh  exported Bounce Kingdom UK → CRM   ·  3 hrs ago
```

The feed stores up to **300 recent events** in shared browser storage (when the platform is loaded as a Claude artifact with shared storage). In standalone mode, the feed is local to your browser.

Use the activity feed in team stand-ups: "What got qualified or exported yesterday?" answers in one glance.

---

## Filtering the Pipeline Board

Filter controls at the top of the Pipeline page:

| Filter | Options |
|--------|---------|
| Country | All countries in dataset |
| Tier | T1 / T2 / T3 |
| Competitive class | Whitespace / Legacy / Specialist / Horizontal |
| Min score | Slider (0–100) |
| Has email | Toggle |
| Recommended action | call_now / nurture / monitor / disqualify |

Filters apply across all columns simultaneously. Column header counts update to reflect the filtered set.

---

## CRM Export

Clicking **Export to CRM** generates a CSV. See [05 — Locations](05-locations.md) for the full three-format export reference (Salesforce / HubSpot / Generic), including the Accounts + Venues dual-sheet structure.

---

## Recovering Disqualified Venues

Disqualified venues are not deleted — they remain in the dataset with `disqualified` status. To reinstate:

1. Switch to **Locations** → apply **Status = Disqualified** filter
2. Click the venue → change status back to `scored` or `qualified`
3. It reappears in the Pipeline board

---

## Pipeline Health Checklist

| Indicator | Healthy | Warning |
|-----------|---------|---------|
| Raw : Enriched | < 30% raw | > 50% raw → run enrichment |
| Scored : Qualified | < 5× | > 10× → reps need to review |
| Qualified : Exported | 1:1 | Qualified piling up → outreach bottleneck |
| Avg confidence (Qualified) | ≥ 0.75 | < 0.65 → qualifying low-confidence leads |
| Avg score (Qualified) | > 65 | < 55 → qualification threshold too low |

---

*Keystone · by Tigapo · Confidential*
