# 08 · Future Vision — Keystone as a Living SaaS Platform

**Keystone · by Tigapo — Internal Documentation**

> **Note on intentional dissonance:** This document describes Keystone as it *will be* — a live, cloud-native SaaS intelligence platform. The current version (v1) is a self-contained HTML file that requires manual data loading. Both are real, and both are deliberate. The gap between them is the product roadmap. This document is written for leadership and investor audiences, as well as for internal team members who want to understand where this is going and why the investment makes sense today.

---

## The Gap — Today vs. Tomorrow

| Dimension | Today (v1 — HTML file) | Tomorrow (Keystone SaaS) |
|-----------|----------------------|--------------------------|
| **Deployment** | Single self-contained HTML file, opened locally | Cloud-hosted web app at `keystone.tigapo.com` |
| **Data loading** | Manual: rep selects CSVs from OneDrive folder each session | Automatic: live SharePoint / Graph API sync + API-fed pipelines refresh daily |
| **Data freshness** | Stale on day 2 — only as fresh as the last import | Continuously live — Google Maps changes flow in within 48 hours |
| **Team access** | Each rep has their own local copy; no shared view | Single shared workspace — every rep sees the same data |
| **Collaboration** | None — pipeline changes live only in one browser | Real-time: status changes, notes, assignments sync instantly across the team |
| **CRM integration** | Manual CSV export → import into Salesforce | Bi-directional Salesforce sync — qualified leads push automatically; won/lost signals flow back |
| **AI capabilities** | Offline-fallback deterministic; Claude only when opened as a Claude artifact | Always-on AI with full Claude access, conversation memory across sessions, proactive alerts |
| **Discovery** | Rep-triggered Apify runs from browser (batch-limited) | Scheduled, territory-assigned discovery runs on cloud infrastructure |
| **Enrichment** | Batch-run manually, one rep at a time | Continuous background enrichment — new venues enriched within hours of discovery |
| **Permissions** | None — anyone with the file sees everything | Role-based access: rep sees their territory; manager sees their region; leadership sees all |
| **Audit trail** | None — no record of who changed what | Full activity log: every status change, export, and note is timestamped and attributed |
| **Alerting** | None — rep must check manually | Proactive: *"New T3 Flagship in your territory — email found, score 88 — call now"* |
| **Enrichment cost** | $0.054/lead at current batch prices | Drops toward zero at scale via batching and API-level caching |
| **Mobile** | Works in browser but not designed for mobile | Mobile companion app — map and copilot on the go |
| **API** | No outbound API | Full API — feed partner tools, custom dashboards, embedded intelligence |

---

## Why the v1 HTML File Was the Right Call

A full SaaS platform takes 6–12 months and significant engineering investment. The HTML file took weeks and proved every critical thesis:

- **Data thesis proven:** The Google Maps + Apollo enrichment pipeline works. The "80% invisible market" claim holds under real data — thousands of venues appear in Keystone that are absent from every IAAPA or B2B database.
- **Scoring model proven:** The 12-signal lead score produces actionable differentiation. Reps have validated it against their own judgment and found it aligns.
- **Market proven:** The addressable universe is real, mappable, and reachable at $0.054/lead.
- **Team conviction proven:** Reps are using it, asking for improvements, and closing with it.

The v1 file is a working prototype that generates real value today. The SaaS platform is the monetised, scaled, productised version of a proven idea. Never apologise for the HTML file — it got the concept to production faster than any other approach would have.

---

## The Phased Roadmap

### Phase 1 — Pilot Validation (Priority Markets: AU, UK, USA)

**Objective:** Prove that Keystone-sourced leads convert at a meaningfully higher rate than leads from traditional sources.

**What happens in Phase 1:**
- Full enrichment run against Australia, United Kingdom, and United States venue datasets (~8,000–10,000 venues total)
- All three markets loaded into the platform; regional sales reps begin working Keystone-sourced leads alongside their existing pipeline
- Scoring model is calibrated against real conversion data — which signals actually predicted a closed deal? Weights are tuned accordingly
- Win/loss data is captured manually (rep-reported) and fed back into the model
- Target: 20+ deals directly attributed to Keystone-sourced leads across the three pilot markets

**Success definition:** Keystone-sourced leads close at a higher rate (or higher ACV) than leads from existing sources. This becomes the business case for Phase 2.

### Phase 2 — Salesforce Integration Rollout

**Objective:** Make Keystone data a first-class data source inside Salesforce — zero manual CSV imports.

**What happens in Phase 2:**
- Bi-directional Salesforce connector deployed
- Qualified leads flow automatically from Keystone → Salesforce as Leads
- Won/lost signals flow back Salesforce → Keystone, updating venue status and feeding the scoring calibration loop
- Custom Salesforce fields mapped (`Lead_Score__c`, `Priority_Score__c`, `Competitive_Class__c`, `Recommended_Action__c`)
- Rep workflow changes: Salesforce is still where deals are managed; Keystone is where discovery, scoring, and outreach prep happens — the two systems stay in sync automatically
- All Tigapo sales reps globally onboarded; territory-based filtering ensures each rep sees their market

**Success definition:** Zero manual CSV exports. Every qualified lead is in Salesforce within 24 hours of being qualified in Keystone. CRM data quality improves because enrichment signals (email, POS, tier) flow in automatically.

### Phase 3 — Keystone as System of Record

**Objective:** Keystone is no longer a prospecting tool — it is the authoritative map of the global FEC market, feeding every sales, marketing, and leadership decision.

**What happens in Phase 3:**
- Discovery runs automatically on a scheduled cadence (90-day refresh per market) — new venues are detected within 48 hours of opening
- Change detection: when a venue's POS system changes, rating drops significantly, or a new location opens, Keystone surfaces an alert to the owning rep
- Proactive AI becomes the primary UX: the morning briefing ("3 new venues in your territory this week. Your highest priority: Jump Republic Birmingham — T3 Flagship, score 89, email found.") is pushed to the rep, not pulled
- Leadership dashboard: board-level view of global penetration, whitespace by region, pipeline velocity, and market growth
- Market intelligence: country-by-country market sizing updates automatically as new venues are discovered and enriched
- **Keystone becomes the system of record for FEC market intelligence** — not just a prospecting tool but the authoritative, continuously-updated map of where the industry is, who runs what, and who's growing

**Success definition:** Leadership references Keystone data in board decks and investor updates. Every new market entry begins with a Keystone territory analysis. No Tigapo rep ever cold-calls a venue that's already in the database without context.

---

## The Proactive Intelligence Vision

The biggest shift from v1 to SaaS is from **reactive** (rep asks a question) to **proactive** (platform surfaces insights without being asked).

### What proactive looks like in Phase 3

**"You have a new venue"**
> *Keystone detected a new FEC opened in Austin, TX: Lazer Blast FEC — 8 machines, no POS detected, 4.7 stars, 47 reviews. Lead score 72. Added to your pipeline. Want me to draft an outreach message?*

**"Something changed"**
> *Galaxy Fun Center in Denver moved from Siriusware to an undetected POS — re-scored. It was Qualified-stale in your pipeline. Flagged for review.*

**"This week's hot list"**
> *Monday briefing: 8 new venues discovered in your territory. 3 score above 75 and have email. Your highest priority: Jump Republic Birmingham — T3 Flagship, Siriusware, score 89.*

**"Before your call"**
> *You have a call with Sky High Trampoline today. Since you last looked: rating dropped 4.4 → 4.1, 23 new reviews mention "long queues" and "broken machines." Suggested hook: operational pressure is high right now.*

---

## The Investment Case in Simple Terms

> Google Maps holds a complete, real-time map of every FEC on Earth. No competitor has systematically extracted, enriched, and scored it. The window to build that asset is open **right now** — before a well-funded competitor closes it.

**The v1 HTML file proves the system works.**
**The SaaS platform scales it.**
**The database being built today is worth significantly more in 3 years** as the FEC market grows 2–3× and Tigapo's penetration compounds on a base it mapped first.

### The Economics

| Item | Cost |
|------|------|
| Full global TAM enrichment (~20,000 venues) | ~$1,340 |
| 3× annual refreshes | ~$460 |
| **Total enrichment budget (Year 1)** | **~$1,800** |

The **initial ask was $2,000** to fund the first full enrichment run. The entire global FEC intelligence database — arguably the most complete ever assembled — costs less than a single trade-show booth.

### ROI Projection (Conservative)

| Metric | Conservative |
|--------|-------------|
| Additional T3 deals sourced from Keystone annually | 10 |
| Average T3 ACV | $60,000 |
| Additional ARR | $600,000 |
| Annual platform investment (engineering + enrichment) | $200,000 |
| **Year 1 ROI** | **3× (300%)** |

---

## What Success Looks Like — 12 Months

| Milestone | Target |
|-----------|--------|
| Phase 1 pilot complete | AU, UK, USA enriched; 20+ deals attributed |
| Scoring model calibrated | Win/loss data from 50+ deals; weights refined |
| Salesforce integration live | Zero manual CSV exports; bi-directional sync operational |
| All reps onboarded | Every Tigapo sales rep globally working from Keystone |
| Global map complete | 15,000+ venues enriched, scored, classified |
| Proactive AI in production | Morning briefings and territory alerts shipped |
| Leadership dashboard live | Board-level view of penetration, whitespace, pipeline velocity |

---

## The Dissonance — and Why It Matters

Every competitor is fishing the same crowded 20% of the market. Keystone gives Tigapo exclusive access to the other 80% — but **only if the team builds the discipline now to work from it systematically**.

The platform is only as powerful as the reps who use it every day. Phase 1's success is not just about proving the data — it is about proving the habit. Reps who build the muscle of starting every morning with Keystone carry that discipline into Phase 2 and Phase 3. Reps who treat it as an optional extra will find it replaced by the competitor who treated it as essential.

The window is real. The cost is negligible. The downside is minimal.

**The map is the moat.**

---

*Keystone · by Tigapo · Confidential — Forward-looking statements reflect Tigapo's product vision as of July 2026 and are subject to change.*
