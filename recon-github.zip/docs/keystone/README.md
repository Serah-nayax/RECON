# Keystone · by Tigapo
### *The intelligence layer the FEC industry runs on.*

**CONFIDENTIAL — Internal use only (Tigapo / Nayax)**

---

## What is Keystone?

Keystone is a live, continuously-refreshed platform that maps every Family Entertainment Center (FEC) operator on Earth, tracks relationships at scale, and turns raw market data into a structured sales asset.

Google Maps holds every FEC on Earth. No one has ever systematically extracted, enriched, and scored it.

**Until now.**

---

## The Four-Line Purpose

| # | Goal | What it means |
|---|------|---------------|
| 01 | **Map the TAM** | A complete, global view of every FEC on Earth — ~20,000 venues across 50+ countries |
| 02 | **Know where we stand** | Overlay Tigapo's existing customers to see penetration, gaps, and white space |
| 03 | **Focus sales efforts** | AI-scored, ranked leads so the team works the right venues in the right order |
| 04 | **Feed the pipeline** | Qualified leads flow directly into Salesforce and outbound marketing channels |

---

## The Market Opportunity

### Red Ocean vs. Blue Ocean

```
RED OCEAN · EVERYONE ELSE
─────────────────────────────────────────────────────────
  ~4,000 IAAPA members & chains  ·  ~20% of the market

  The same contested databases. The same known accounts.
  Every competitor already fishing here.


BLUE OCEAN · KEYSTONE
─────────────────────────────────────────────────────────
  ~15–20K independent venues  ·  ~80% of the market

  Invisible to every B2B list.
  Keystone maps it first — and owns the map.

  Independent operators. New openings. No trade-show
  presence. Enriched, scored, fed straight into the funnel.
```

**~80% of the FEC market is invisible to the B2B databases every competitor uses.** Keystone maps the rest.

### Why Act Now

The FEC market is projected to grow **2–3× over the next decade**. Mapping venues now means owning those relationships as the market triples. Every relationship seeded today is worth 3× more by the end of the decade.

---

## The Economics

| Enrichment layer | Cost per 1,000 | What it provides |
|-----------------|---------------|------------------|
| Base scrape | $1.50 | Name, address, phone, hours, categories, ratings |
| Relevance filter | $0.53 | FEC keyword & category filtering |
| Place details | $1.05 | Website, popular times, business attributes |
| Company contacts | $1.05 | Owner name, title, LinkedIn URL |
| Business leads | $4.00 | Verified email, direct phone, company size |
| Email verification | $2.00 | Deliverability check — removes bounces |
| Social media | $6.00 | Facebook & Instagram profiles |
| **Total** | **$16.13 / 1,000** | **Full enrichment stack** |

**$0.054 per fully-enriched lead.** All enrichment runs inside a single Apify actor. Zero external API accounts. One bill, one platform.

> The entire global TAM (~20,000 venues) costs ~$1,340 to enrich. Three annual refreshes add ~$460. Total expected spend: ~$1,800 — arguably the cheapest enterprise-grade sales intelligence asset in Nayax's history.

---

## Quick-Start Checklist

For a new team member — get productive in 15 minutes:

- [ ] Open the HTML file in Chrome or Edge
- [ ] Click **Sync data** → select the CSVs from your OneDrive-synced FEC PROJECT folder
- [ ] Open **Dashboard** — scan the KPI strip and market depth panel
- [ ] Open **Map** → switch to **Score mode** → zoom into your territory
- [ ] Find a green (Score 80+) cluster and click a venue
- [ ] Click "View in Locations" from the pop-up → read the outreach message
- [ ] Export to CRM or copy the email draft

---

## Documentation Reading Order

| Doc | What to read | Who needs it |
|-----|-------------|-------------|
| **You are here** — README | Vision, opportunity, economics | Everyone |
| [01 — Getting Started](01-getting-started.md) | Loading data, UI basics | Day-one users |
| [02 — Dashboard](02-dashboard.md) | KPIs, market intelligence, competitive overview | All reps, managers |
| [03 — Map](03-map.md) | Geographic discovery, 5 map modes | Reps doing territory work |
| [04 — Pipeline](04-pipeline.md) | Lead stages, enrichment, scoring | All reps |
| [05 — Locations & Outreach](05-locations.md) | Venue intelligence, message builder, CRM export | All reps |
| [06 — Compare, Sources & AI](06-compare-and-sources.md) | Region benchmarking, data sources, AI copilot | Managers, strategists |
| [07 — Scoring Reference](07-scoring-and-competitive.md) | Every scoring signal, competitive logic | Power users |
| [08 — Future Vision](08-future-vision.md) | Where Keystone is going | Leadership, all team |

---

*Keystone · by Tigapo · Confidential*
