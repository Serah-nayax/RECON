# Recon

Business intelligence and lead-generation platform: Google Maps lead search, website
crawling, AI-generated intel reports, and ICP-based lead qualification.

**Created by Salomon Sverdlov.**

See [`docs/`](docs/README.md) for the user guide.

## License

Copyright (c) 2026 Salomon Sverdlov. Licensed under the
[PolyForm Noncommercial License 1.0.0](LICENSE.md).

- **Noncommercial use** (personal projects, learning, research, nonprofit use) is free,
  as long as you keep the copyright notice and credit Salomon Sverdlov as the original
  author.
- **Commercial use**, including selling any version of Recon or using it to make money,
  requires a paid commercial license. See [COMMERCIAL-LICENSE.md](COMMERCIAL-LICENSE.md)
  or contact [sal.sverdlov@gmail.com](mailto:sal.sverdlov@gmail.com).
